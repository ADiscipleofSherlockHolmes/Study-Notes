//将该文本固定在宽度为30的范围内
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <windows.h>
#include <conio.h>
#include <direct.h>
#include <time.h>
#define MAXPATH  1024

typedef struct link_node
{
	char data;
	int flag;
	struct link_node *llink,*rlink;
}dnode;


//设置颜色：                                                                                                                                                                                                             
void setColor(unsigned short ForeColor=7,unsigned short BackGroundColor=0)
{
	HANDLE handle=GetStdHandle(STD_OUTPUT_HANDLE);//获取当前窗口句柄
	SetConsoleTextAttribute(handle,ForeColor+BackGroundColor*0x10);//设置颜色
}
//设置光标位置
void SetPos(int x,int y)
{
	COORD pos;
	HANDLE handle;
	pos.X=x;
	pos.Y=y;
	handle=GetStdHandle(STD_OUTPUT_HANDLE);
	SetConsoleCursorPosition(handle,pos);
}
//封面
void drawmain1()
{
	setColor(11,0);
	printf("                              *******************************\n");
	printf("                             *                               *\n");
	printf("                            *                                 *\n");
	printf("                           *        欢迎使用文本编辑器         *\n");
	printf("                            *                                 *\n");
	printf("                             *                               *\n");
	printf("                              *******************************\n");
}
//选项
void drawmain2()
{
	printf("          ------------------------------------------------------------------------------------------------------------\n");
	printf("          *                                           文本编辑器功能介绍表	        			     *                \n");
	printf("          ------------------------------------------------------------------------------------------------------------\n");
	printf("          *   1、 输入文本串								8、存盘			     *\n");
	printf("          ------------------------------------------------------------------------------------------------------------\n");
	printf("          *   2、 打印输出文本串							9、取盘			     *\n ");
	printf("          -----------------------------------------------------------------------------------------------------------\n");
	printf("          *   3、 输出该文本的行数							10、在某一行某一列插入字符串 *\n");
	printf("          ------------------------------------------------------------------------------------------------------------\n");
	printf("          *   4、 统计文章中的英文字母数，空格数，总字数				11、替换字符串(等长、不等长) *\n ");
	printf("          -----------------------------------------------------------------------------------------------------------\n");
	printf("          *   5、 统计某一字符串在文章中出现的次数，并输出该次数			12、块移动		     *\n");
	printf("          ------------------------------------------------------------------------------------------------------------\n");
	printf("          *   6、 删除某一子串，并将后面的字符前移					13、释放空间		     *\n");
	printf("          ------------------------------------------------------------------------------------------------------------\n");
	printf("          *   7、 检索输出某个单词出现在文本中的行号、在该行中出现的次数以及位置	14、退出程序	   	     *\n");
	printf("          ------------------------------------------------------------------------------------------------------------\n");
}
//动画,飞舞的字符
void drawmain3()
{
	char str[]={"QWERTYUIOPASDFGHJKLZXCVBNMqwaszxcderfvbgtyhnmjuiklop1234567890"};
	int i,j,len=strlen(str);
	int x=0,y=5,ch=0,color=1,left=0,right=100,top=0,bottom=20;
	int vx=1,vy=1,vchar=1,vcolor=1;
	while(!kbhit())
	{
		x=x+vx;
		y=y+vy;
		drawmain1();
		color=color+vcolor;
		setColor(color,0);	
		printf("按回车键(Enter)进入主界面");
		Sleep(200);
		system("cls");
		for(i=0;i<x;i++)
			printf("\n");
		for(j=0;j<y;j++)
			printf(" ");
		color=color+vcolor;
		setColor(color,0);	
		printf("%c",str[ch+vchar]);
		ch=ch+vchar;
		printf("\n");
		if((x==top)||(x==bottom))	vx=-vx;
		if((y==left)||(y==right))	vy=-vy;
		if((ch==0)||(ch==len-1))	vchar=-vchar;
		if((color==1)||(color==15))	vcolor=-vcolor;
	}
}
void drawmain4()
{
	setColor(11,0);
	printf("                              *******************************\n");
	printf("                             *                               *\n");
	printf("                            *                                 *\n");
	printf("                           *        感谢使用，下次再会         *\n");
	printf("                            *                                 *\n");
	printf("                             *                               *\n");
	printf("                              *******************************\n");
}


//初始化
dnode *init()
{
	dnode *head;
	head=(dnode*)malloc(sizeof(dnode));
	head->llink=NULL;
	head->rlink=NULL;
	return head;
}
//释放空间,在主函数中+"释放成功"
void free_link(dnode *front,dnode *rear)//rear指向要删除的串的最后一个结点
{
	dnode *p=front;
	while(p!=rear)
	{
		front=front->rlink;
		free(p);
		p=front;
	}
	free(p);
}
void free_total(dnode *head)
{
	dnode *p;
	if(!head->rlink)
	{
		printf("该文本串为空！\n");
		return ;
	}
	while(head)
	{
		p=head;
		head=head->rlink;
		free(p);
	}
	return ;
}
//创建(带头节点)，用户手动换行：flag=1，自动换行flag=0
dnode *creat(dnode *head)
{
	dnode *p,*q=head;
	int i,len;
	char str[1000];
	memset(str,0,sizeof(str));
	while(1)//用户按下回车键表示想要换成下一段。最后一个字符是‘#’则表示输入结束
	{
		i=0;
		gets(str);
		len=strlen(str);
		while(str[i])
		{
			if(i%30==0)//需要换行，但是首先判断是不是最后一个字符，是不是‘#’
			{
				if(i==len-1)//是最后一个字符,或者第一个字符
				{
					if(str[i]=='#')
					{
						printf("\n创建成功!\n");
						return head;
					}
					else//如果最后一个字符不是“#”,那么
					{
						p=(dnode*)malloc(sizeof(dnode));
						p->data='\n';
						p->flag=0;//第一行是0~29，所以第30个字符是在第二行，所以在29~30之间的换行是自动添加
						p->llink=q;
						p->rlink=NULL;
						q->rlink=p;
						q=p;
						p=(dnode*)malloc(sizeof(dnode));
						p->data=str[i];
						p->llink=q;
						p->rlink=NULL;
						q->rlink=p;
						q=p;
						break;
					}
				}
				else//不是最后一个字符 ,自动换行
				{
					p=(dnode*)malloc(sizeof(dnode));
					p->data='\n';
					if(i==0)
						p->flag=1;//第一个字符默认为用户手动换行
					else
						p->flag=0;//自动换行
					p->llink=q;
					p->rlink=NULL;
					q->rlink=p;
					q=p;
					p=(dnode*)malloc(sizeof(dnode));
					p->data=str[i];
					p->llink=q;
					p->rlink=NULL;
					q->rlink=p;
					q=p;
					i++;
				}
			}
			else//不要换行
			{
				if(i==len-1)//最后一个字符
				{
					if(str[i]=='#')
					{
						printf("\n创建成功!\n");
						return head;
					}
					else
					{
						p=(dnode*)malloc(sizeof(dnode));
						p->data=str[i];
						p->llink=q;
						p->rlink=NULL;
						q->rlink=p;
						q=p;
						break;
					}
				}
				else//不是最后一个字符，不要换行，最普通情况
				{
					p=(dnode*)malloc(sizeof(dnode));
					p->data=str[i];
					p->llink=q;
					p->rlink=NULL;
					q->rlink=p;
					q=p;
					i++;
				}
			}
		}
	}
}
//打印输出
void print(dnode *head)
{
	dnode *p=head->rlink;
	if(!p)
	{
		printf("该文本串为空！请先选择（1）进行创建\n");
		return ;
	}
	while(p)
	{
		printf("%c",p->data);
		p=p->rlink;
	}
	printf("\n\n");
	return ;
}



//统计行号
int line_num(dnode *head)
{
	int count=0;
	dnode *p=head->rlink;
	if(!p)
	{
		printf("该文本串为空！请先选择（1）进行创建\n");
		return 0;
	}
	while(p)
	{
		if(p->data=='\n')	count++;
		p=p->rlink;
	}
	return count;
}
//返回某一行
dnode *find_certain_line(dnode *head,int line)
{
	int line_cnt=0;
	dnode *p=head->rlink;
	if(!head->rlink)
	{
		printf("该文本串为空！请先选择（1）进行创建\n");
		return head;
	}
	while(p)
	{
		if(p->data=='\n')
		{
			line_cnt++;
			if(line_cnt==line)
				return p;
			p=p->rlink;
		}
		else	p=p->rlink;
	}
	return p;
}
//返回某一列
dnode *find_certain_col(dnode *head,int line,int col)
{
	dnode *p=find_certain_line(head,line);
	int col_num=0,flag=0;
	while(col_num!=col && p)
	{
		if(p->data=='\n')	
			flag++;
		if(flag>1)	
			return NULL;
		col_num++;
		p=p->rlink;
	}
	return p;
}
//统计某一行的列数
int col_num(dnode *head,int line)
{
	dnode *p=find_certain_line(head,line);//p指向“\n”
	int num;
	if(line==line_num(head))
	{
		while(p)
		{
			if(p->data=='\n')
			{
				p=p->rlink;num=0;
			}
			else	
			{
				num++;
				p=p->rlink;
			}
		}
		return num;
	}
	else
	{
		p=p->rlink;num=0;
		while(p->data!='\n')
		{
			num++;
			p=p->rlink;
		}
		return num;
	}
}
//返回链表的最后一个结点
dnode *final(dnode *head)
{
	dnode *p=head->rlink;
	while(p->rlink)	p=p->rlink;
	return p;
}
//获取next数组
void getnext(int *next,char *s)
{
	memset(next,0,sizeof(next));
	int i,j,len;
	len=strlen(s);
	next[0]=-1;
	i=0;j=-1;
	while(i<len)
	{
		if(j==-1 || s[j]==s[i])
		{
			++i;++j;
			if(s[j]!=s[i])	next[i]=j;
			else	next[i]=next[j];
		}
		else	j=next[j];
	}
}
//kmp搜索某一字符串出现的次数
void kmp_search_count(int *next,dnode *head,char *s)
{
	int j=0,len=strlen(s),count=0;
	dnode *p=head->rlink;
	if(!head->rlink)
	{
		printf("该文本串为空！请先选择（1）进行创建\n");
		return ;
	}
	while(p!=NULL && j<len)
	{
		if(j==-1 || p->data==s[j])
		{
			p=p->rlink;
			j++;
		}
		else	j=next[j];
		if(j==len)
		{
			count++;
			j=next[j];
		}
	}
	printf("\"%s\"在文本串中出现%d次\n",s,count);
}
//计数英文字母数，空格数，总字数
void english_num_blank_total(dnode *head)
{
	dnode *p=head->rlink;
	if(!p)
	{
		printf("该文本串为空！请先选择（1）进行创建\n");
		return ;
	}
	int english_num=0,blank_num=0,total_num=0;
	while(p)
	{
		if((p->data>='A' && p->data <='Z')||(p->data>='a' && p->data<='z'))	
			english_num++;
		else if(p->data==' ')	
			blank_num++;
		if((p->data>='0' && p->data<='9') || (p->data>='A' && p->data <='Z') || (p->data>='a' && p->data<='z'))	
			total_num++;
		p=p->rlink;
	}
	printf("一共有%d个英文字母 ,有%d个空格数 , 总字数为%d\n",english_num,blank_num,total_num);
}
//kmp搜索某一单词出现的位置
void kmp_position(int *next,dnode *head,char *s)
{
	dnode *p=head->rlink,*p1,*q1;
	if(!p)
	{
		printf("该文本串为空！请先选择（1）进行创建\n");
		return ;
	}
	int i=0,j=0,len=strlen(s),line=0,col=0,count=0,k,flag;
	while(p!=NULL && j<len)
	{
		if(j==-1 || p->data==s[j])
		{
			if(p->data=='\n')
			{
				if(line!=0 && count!=0)
					printf("在第%d行中出现%d次\n\n",line,count);
				count=0;
				line++;
				col=1;
				j=0;
				p=p->rlink;
				continue;
			}
			else
			{
				col++;
				p=p->rlink;
				j++;
			}
		}
		else	j=next[j];
		if(j==len)
		{
			flag=len;
			if(p==NULL)
			{
				p1=final(head);
				q1=p1;
				while(flag--)
					q1=q1->llink;
				if(q1->data==' ')
				{
					count++;
					printf("line = %d.col = %d\n",line,col-len);
				}
			}
			else if(p!=NULL)
			{
				q1=p;
				while(flag--)
					q1=q1->llink;
				q1=q1->llink;
				if((q1->data==' '||q1->data=='\n') && p->data==' ')
				{
					count++;
					printf("line = %d.col = %d\n",line,col-len);
				}
			}
			j=next[j];
		}
	}
	if(count!=0)
		printf("在第%d行中出现%d次\n\n",line,count);
	else
		printf("没有找到该单词！\n");
}
//正确存盘
void save(dnode *head)
{
	dnode *p=head->rlink;
	if(!p)
	{
		printf("该文本串为空！请先选择（1）进行创建\n");
		return ;
	}
	FILE *f;
	char filename[20];
	printf("请输入要存入的文件名：");
	scanf("%s",filename);
	getchar();
	f=fopen(filename,"w+");
	if(f==NULL)
	{
		printf("无法打开\n");
		return ;
	}
	else
	{
		while(p)
		{
			fputc(p->data,f);
			p=p->rlink;
		}
		printf("存盘成功\n");
		fclose(f);
	}
	char buffer[MAXPATH];
	_getcwd(buffer,MAXPATH);
	printf("文件 %s 保存在 %s \n",filename,buffer);
	return ;
}
//正确取盘,在此之前需要head=init()
dnode *take(dnode *head)
{
	FILE *fp;
	dnode *q=head,*p;
	char ch;
	char filename[20];
	printf("请输入要打开的文件名：\n");
	scanf("%s",filename);
	getchar();
    if((fp=fopen(filename,"r"))==NULL)
	{   
		printf("文件无法打开\n");
		return head;
	}
	free_total(head);
	dnode *head1;
	head1=init();
	q=head1;
	while((ch=fgetc(fp))!=EOF)
	{
		p=(dnode*)malloc(sizeof(dnode));
		p->data=ch;
		p->rlink=NULL;
		p->llink=q;
		q->rlink=p;
		q=p;
	}
	q->rlink=NULL;
	p=head1->rlink;
	while(p)
	{
		printf("%c",p->data);
		p=p->rlink;
	}
	printf("\n取盘成功\n");
	fclose(fp);
	return head1;
}
//修改换行
dnode *change_blank(dnode *head)
{
	dnode *p=head->rlink,*q,*p1;
	while(p)
	{
		if(p->data=='\n' && p->flag==1)
			p=p->rlink;
		else if(p->data=='\n'  && p->flag==0)
		{
			q=p;
			p=p->llink;
			p->rlink=q->rlink;
			q->rlink->llink=p;
			q->llink=NULL;
			q->rlink=NULL;
			free(q);
		}
		else
			p=p->rlink;
	}
	int count;//计数，一行有30个字符的时候需要换行
	p=head->rlink;
	while(p)
	{
		if(p->data=='\n' && p->flag==1)
		{
			count=1;
			p=p->rlink;
		}
		else if(count==30 && p->rlink->data!='\n')
		{
			//q是后一个结点，p是前一个结点
			q=p->rlink;
			p1=(dnode*)malloc(sizeof(dnode));
			p1->data='\n';
			p1->flag=0;//自动换行
			p1->rlink=q;
			p1->llink=p;
			q->llink=p1;
			p->rlink=p1;
			//"\n"插入完成
			count=1;
			p=q;
		}
		else if(count==30 && p->rlink->data=='\n' && p->rlink->flag==1)
			p=p->rlink;
		else
		{
			p=p->rlink;
			count++;
		}
	}
	return head;
}
//删除某一子串，用户手动换行：flag=1，自动换行flag=0
dnode *del_substring(dnode *head,char *s,int *next)
{
	char t[100];
	dnode *p=head->rlink,*front,*rear,*q,*p1,*front1,*rear1;
	if(!p)
	{
		printf("该文本串为空！请先选择（1）进行创建\n");
		return head;
	}
	int j=0,i=0,len=strlen(s),flag,k,flag1=0;
	while(p!=NULL && j<len)
	{
		if(j==-1 || p->data==s[j])
		{
			p=p->rlink;
			j++;
		}
		else
			j=next[j];
		if(j==len && p!=NULL)//删除中间的某一段
		{
			flag1=1;//标记找到模式串，要进行删除操作
			flag=len;
			front=p;
			while(flag--)
				front=front->llink;
			front1=front;//删除串的第一个字符
			front=front->llink;//要删除结点的前一个结点
			rear=p;//删除串结束的后一个字符
			rear1=rear->llink;//删除串的最后一个字符
			//******先把左右指针赋NULL，相当于断开这个链表
			front->rlink=NULL;//*
			front1->llink=NULL;
			rear1->rlink=NULL;
			rear->llink=NULL;//*
			//******
			free_link(front1,rear1);
			front->rlink=rear;
			rear->llink=front;
			j=next[j];
		}
		else if(j==len && p==NULL)
		{
			flag=len;
			rear=final(head);//只向该双链表的最后一个节点
			rear1=rear;
			while(flag--)
				rear=rear->llink;
			front1=rear->rlink;
			rear->rlink=NULL;
			front1->llink=NULL;
			free_link(front1,rear1);
		}
	}
	head=change_blank(head);
	if(flag1)
		printf("删除成功！\n");
	else
		printf("未找到匹配的字符串\n");
	return head;
}
//插入
dnode *insert(dnode *head,char *str,int line,int col)
{
	if(!head->rlink)
	{
		printf("该文本串为空！请先选择（1）进行创建\n");
		return head;
	}
	int line_cnt=0;//找到line行
	int col_cnt=0; //找到col列
	int len=strlen(str);//要插入字符的长度
	int flag=len;
	int i;
	int total_count=0;//计算要插入那行的总字符数
	dnode *p,*front,*rear,*p1,*q1,*pp;
	if(line<=0 || line>line_num(head))
	{
		printf("line_num = %d\n",line_num(head));
		printf("行数输入有误！请重新输入！\n");
		return head;
	}
	if(col<=0 || col>31)
	{
		printf("列数输入有误！请重新输入！\n");
		return head;
	}
	//找到指定的行
	p=find_certain_line(head,line);
	pp=p->rlink;
	//计算该行的总字数
	total_count=col_num(head,line);
	if(col>total_count+1)
	{
		printf("输出的列数有错,请重新输入！\n");
		return head;
	}
	if(col==total_count+1)
	{
		pp=p->rlink;
		if(line_num(head)==line)//如果是要在最后一行的末尾插入
			while(pp->rlink!=NULL)//让pp指向文本串的最后一个字符
				pp=pp->rlink;
		else//在不是最后一行的末尾插入
			while(pp->rlink->data!='\n')//让pp指向这一行的最后一个字符
				pp=pp->rlink;
		q1=pp;//该行的最后一个字符
		pp=pp->rlink;//指向“\n”或者NULL；
		//下面三行是先断开
		q1->rlink=NULL;
		if(pp)
			pp->llink=NULL;
		i=0;
		while(str[i])
		{
			p1=(dnode*)malloc(sizeof(dnode));
			p1->data=str[i];
			p1->rlink=NULL;
			p1->llink=q1;
			q1->rlink=p1;
			q1=p1;
			i++;
		}
		q1->rlink=pp;
		if(pp)
			pp->llink=q1;
	}
	else
	{
		col_cnt=0;
		pp=p;
		while(col_cnt<=total_count)
		{
			col_cnt++;
			pp=pp->rlink;
			if(col_cnt==col)	break;
		}
		//printf("col_cnt = %d\n p->data = %c\n",col_cnt,pp->data);
		i=0;
		q1=pp->llink;
		q1->rlink=NULL;
		pp->llink=NULL;
		while(str[i])
		{
			p1=(dnode*)malloc(sizeof(dnode));
			p1->data=str[i];
			p1->rlink=NULL;
			p1->llink=q1;
			q1->rlink=p1;
			q1=p1;
			i++;
		}
		q1->rlink=pp;
		pp->llink=q1;
	}
	head=change_blank(head);
	printf("插入成功！\n");
	return head;
}
//替换,s1为模式串，s2为替换串
dnode *repalce(dnode *head,char *s1,char *s2,int *next)
{
	dnode *p=head->rlink,*p1,*q1,*front,*rear,*front1,*rear1;
	if(!head->rlink)
	{
		printf("该文本串为空！请先选择（1）进行创建\n");
		return head;
	}
	int len=strlen(s1),j=0,i,flag,flag1=0;
	while(p!=NULL && j<len)
	{
		if(j==-1 || p->data==s1[j])
		{
			p=p->rlink;
			j++;
		}
		else
			j=next[j];
		if(j==len && p!=NULL)//在中间替换
		{
			flag1=1;
			flag=len;
			rear1=p->llink;
			front=p;
			while(flag--)	
				front=front->llink;
			front1=front;
			front=front->llink;
			//先断开
			front->rlink=NULL;
			front1->llink=NULL;
			p->llink=NULL;
			rear1->rlink=NULL;
			i=0;
			while(s2[i])
			{
				p1=(dnode*)malloc(sizeof(dnode));
				p1->data=s2[i];
				p1->rlink=NULL;
				p1->llink=front;
				front->rlink=p1;
				front=p1;
				i++;
			}
			front->rlink=p;
			p->llink=front;
			free_link(front1,rear1);
			j=next[j];
		}
		else if(j==len && p==NULL)
		{
			flag=len;
			rear1=final(head);
			front=rear1;
			while(flag--)
				front=front->llink;
			front1=front->rlink;
			//断开
			front->rlink=NULL;
			front1->llink=NULL;
			i=0;
			while(s2[i])
			{
				p1=(dnode*)malloc(sizeof(dnode));
				p1->data=s2[i];
				p1->rlink=NULL;
				p1->llink=front;
				front->rlink=p1;
				front=p1;
				i++;
			}
			free_link(front1,rear1);
		}
	}
	if(flag1==0)
	{
		printf("没有找到匹配的字符串！\n");
	}
	return head;
}
//块移动
dnode *move(dnode *head)
{
	if(!head->rlink)
	{
		printf("该文本串为空！请先选择（1）输入文本串！!\n");
		return head;
	}
	int line1,line2,col1,col2;
	//输入+判断非法情况
	printf("请用户输入要移动的块的主对角线的两点坐标坐标：\n");
	printf("(注：在选区矩形的时候只选取完整的矩形块)\n");
	printf("横坐标1：");scanf("%d",&line1);
	if(line1<=0 || line1>line_num(head))
	{
		printf("行数输入有误，请重新输入！\n");
		return head;
	}
	printf("纵坐标1：");scanf("%d",&col1);
	//printf("col=%d\n",col_num(head,line1));
	if(col1<=0 || col1>col_num(head,line1))
	{
		printf("列数输入有误，请重新输入！\n");
		return head;
	}
	printf("横坐标2：");scanf("%d",&line2);
	if(line2<=0 || line2>line_num(head))
	{
		printf("行数输入有误，请重新输入！\n");
		return head;
	}
	printf("纵坐标2：");scanf("%d",&col2);
	if(col2<=0 || col2>col_num(head,line2))
	{
		printf("列数输入有误，请重新输入！\n");
		return head;
	}
	//先保存到文件
	save(head);
	int t;
	//line1是较小的值，col1是较小的值
	if(line1>line2) {t=line1;line1=line2;line2=t;}
	if(col1>col2)	{t=col1;col1=col2;col2=t;}
	dnode *p,*q,*q1,*p1;
	dnode *temp[20];int size;//size记录数组中到底有多少数
	int flag;//标记到底输入的是哪种情况
	if(line1==line2 && col1==col2)//输入的行数和列数相等，则说明，只移动一个点
	{
		flag=1;
		p=find_certain_col(head,line1,col1);
		setColor(0,8);
		printf("\n选中的字符串是：%c\n\n",p->data);
		setColor(11,0);
		if(p->rlink!=NULL)//把p从链表中取出来
		{
			p->llink->rlink=p->rlink;
			p->rlink->llink=p->llink;
			p->llink=NULL;
			p->rlink=NULL;
		}
		else//把p从链表中取出来
		{
			p->llink->rlink=NULL;
			p->llink=NULL;
		}	
	}
	else if(line1==line2 && col1!=col2)//行块移动
	{
		flag=2;
		p=find_certain_col(head,line1,col1);
		q=find_certain_col(head,line1,col2);
		printf("\n选中的字符串是：");
		setColor(0,8);
		p1=p;
		q1=q;
		while(p1!=q1->rlink)
		{
			printf("%c",p1->data);
			p1=p1->rlink;
		}
		setColor(11,0);
		printf("\n\n");
		if(q->rlink!=NULL)//先把这一小段分离出来,q不是最后一个结点
		{
			p->llink->rlink=q->rlink;
			q->rlink->llink=p->llink;
			p->llink=NULL;
			q->rlink=NULL;
		}
		else//q是最后一个结点,分离出这一小段
		{
			p->llink->rlink=NULL;
			p->llink=NULL;
		}
	}
	else if(line1!=line2 && col1==col2)//列块移动
	{
		flag=3;
		int i=0;
		memset(temp,NULL,sizeof(temp));
		int k1=line1;
		while(k1!=line2+1)
		{	
			//锁定位置
			p=find_certain_col(head,k1,col1);
			if(p!=NULL && p->data!='\n')
			{
				//调整指针
				if(p->rlink!=NULL)//中间位置
				{
					p->rlink->llink=p->llink;
					p->llink->rlink=p->rlink;
					p->llink=NULL;
					p->rlink=NULL;
				}
				else if(p->rlink==NULL)
				{
					p->llink->rlink=NULL;
					p->llink=NULL;
				}
				//存入数组
				temp[i++]=p;
			}
			else
				temp[i++]=head;
			k1++;
		}
		size=i;
		i=0;printf("\n选中的字符是：\n");
		setColor(0,8);
		while(temp[i])
		{
			if(temp[i]!=head)
				printf("%c\n",temp[i++]->data);
			else
				printf(" \n",temp[i++]->data);
		}
		printf("\n");
		setColor(11,0);
	}
	else if(line1!=line2 && col1!=col2)
	{
		flag=4;
		memset(temp,NULL,sizeof(temp));
		int i,j,k=0;
		for(i=line1;i<=line2;i++)
		{
			p=find_certain_col(head,i,col1);p1=p;
			q=find_certain_col(head,i,col2);
		//	printf("%c %c\n",p->data,q->data);
			//断开连接
			if(q->rlink!=NULL)
			{
				p->llink->rlink=q->rlink;
				q->rlink->llink=p->llink;
				p->llink=NULL;
				q->rlink=NULL;
			}
			else 
			{
				p->llink->rlink=q->rlink;
				p->llink=NULL;
			}
			//存入数组
			temp[k++]=p1;
		}
		size=k;
		i=0;
		printf("\n取出的字符串是：\n");
		setColor(0,8);
		while(temp[i])
		{
			p=temp[i++];
			while(p)
			{
				printf("%c",p->data);
				p=p->rlink;
			}
			printf("\n");
		}
		setColor(11,0);
		p=final(head);
		if(p->data=='\n')
		{
			p->llink->rlink=NULL;
			free(p);
		}
	}
	printf("取出后：\n");
	print(head);
	printf("请输入要插入的位置的坐标：\n");
	int x,y;
	printf("新 横坐标：");scanf("%d",&x);
	if(x<=0 || x>line_num(head))
	{
		printf("行数输入有误，请重新输入！\n");
		free_total(head);
		head=init();
		head=take(head);
		return head;
	}
	printf("新 纵坐标：");scanf("%d",&y);getchar();
	if(y<=0 || y>col_num(head,x))
	{
		printf("列数输入有误，请重新输入！\n");
		free_total(head);
		head=init();
		head=take(head);
		return head;
	}
	if(flag==1)//取出一个字符
	{
		q=find_certain_col(head,x,y);
		q1=q->llink;
		p->llink=q1;
		p->rlink=q;
		q1->rlink=p;
		q->llink=p;
	}
	else if(flag==2)//取出一行
	{
		//p是开始的那个结点，q是结束的那个结点
		p1=find_certain_col(head,x,y);//p1是现在需要插入的那个位置+
		q1=p1->llink;
		p->llink=q1;
		q->rlink=p1;
		q1->rlink=p;
		p1->llink=q;
	}
	else if(flag==3)
	{
		if(x+size-1>line_num(head))
		{
			printf("截取的列块的长度是%d，第%d行到最后一行只有%d行，无法插入",size,x,line_num(head)-x+1);
			free_total(head);
			head=init();
			head=take(head);
			return head;
		}
		int k=x,i=0;
		while(temp[i])
		{
			p=find_certain_col(head,k,y);
			if(temp[i]==head)//这一行不需要插入
			{
				i++;k++;continue;//换行，也换元素
			}
			if(p!=NULL)//p不是空则插到p的前面
			{
				q=p->llink;
				temp[i]->llink=q;
				temp[i]->rlink=p;
				q->rlink=temp[i];
				p->llink=temp[i];
			}
			else//查到这一行的末尾
			{
				p=find_certain_col(head,k,col_num(head,k));//p现在指向这一行的最后一个结点
				q=p->rlink;
				if(q!=NULL)//查到p的后面
				{
					temp[i]->llink=p;
					temp[i]->rlink=q;
					p->rlink=temp[i];
					q->llink=temp[i];
				}
				else
				{
					//temp[i]->rlink=NULL;
					temp[i]->llink=p;
					p->rlink=temp[i];
				}
			}
			i++;k++;
		}
	}
	else if(flag==4)//块插入
	{
		if(x+line2-line1>line_num(head))
		{
			printf("该矩阵块一共有%d行，但是第%d行到最后一行只有%d行，无法插入，请重新输入数据！\n",line2-line1+1,x,line_num(head)-x+1);
			free_total(head);
			head=init();
			head=take(head);
			return head;
		}
		int k=x,i=0;
		while(temp[i])
		{
			p=find_certain_col(head,k,y);
			if(p!=NULL)//则把他插到找到的该字符的前面
			{
				q=p->llink;
				p1=temp[i];
				while(p1->rlink)	
					p1=p1->rlink;
				q1=temp[i];
				q1->llink=q;
				p1->rlink=p;
				q->rlink=q1;
				p->llink=p1;
			}
			else//p为空的话，则插到该行的最后
			{
				p=find_certain_col(head,k,col_num(head,k));//p现在指向这一行的最后一个结点
				if(p->rlink!=NULL)
				{
					q=p->rlink;
					q1=temp[i];
					while(q1->rlink)	
						q1=q1->rlink;
					p1=temp[i];
					p1->llink=p;
					q1->rlink=q;
					p->rlink=p1;
					q->llink=q1;
				}
				else
				{
					temp[i]->llink=p;
					p->rlink=temp[i];
				}
			}
			i++;k++;
		}
	}
	printf("插入后：\n");
	print(head);
	printf("根据每行最多只能容纳30个字符，进行调整：\n");
	head=change_blank(head);
	print(head);
	return head;
}

 
int next[80];
char s1[1000],s2[1000];//s1一般为查找串，s2为替换串
int main()
{
	system("mode con cols=180 lines=120");
	setColor(11,0);
	while(!kbhit())
	{
		drawmain3();	
		system("cls");
	}
	setColor(11,0);
	getchar();
	dnode *head;
	head=init();
	int next[50];
	char s1[100],s2[100];
	int i;
	while(1)
	{
		drawmain2();
		printf("请输入您的选择：");
		scanf("%d",&i);
		getchar();
		switch(i)
		{
		case 1://输入字符串内容
			{
				printf("请输入文本串：\n");
				head=creat(head);
				break;
			}
		case 2://d打印该字符串内容
			{
				print(head);
				break;
			}
		case 3://输出字符串的行数
			{
				print(head);
				int line = line_num(head);
				printf("一共有%d行\n",line);
				break;
			}
		case 4://统计文章中的英文字母数，空格数，总字数
			{
				print(head);
				english_num_blank_total(head);
				break;
			}
		case 5://统计某一字符串在文章中出现的次数，并输出该次数；
			{
				print(head);
				printf("请输入想要查找的字符串：");
				memset(s1,0,sizeof(s1));
				gets(s1);
				getnext(next,s1);
				kmp_search_count(next,head,s1);
				break;
			}
		case 6://删除某一子串，并将后面的字符前移；
			{
				print(head);
				printf("请输入想要删除的字符串：");
				memset(s1,0,sizeof(s1));
				gets(s1);
				getnext(next,s1);
				head=del_substring(head,s1,next);
				print(head);
				break;
			}
		case 7://检索输出某个单词出现在文本中的行号、在该行中出现的次数以及位置；
			{
				print(head);
				printf("请输入想要查找的字符串：");
				memset(s1,0,sizeof(s1));
				gets(s1);
				getnext(next,s1);
				kmp_position(next,head,s1);
				break;
			}
		case 8://正确存盘
			{
				save(head);
				break;
			}
		case 9://正确取盘
			{
				head=take(head);
				break;
			}
		case 10://在某一行某一列插入字符串
			{
				print(head);
				int line,col;
				printf("请输入要插入的字符串：");
				memset(s1,0,sizeof(s1));
				gets(s1);
				printf("请输入要插入的行数：");
				scanf("%d",&line);
				printf("请输入要插入的列数：");
				scanf("%d",&col);
				getchar();
				head=insert(head,s1,line,col);
				print(head);
				break;
			}
		case 11://替换，等长不等长
			{
				print(head);
				printf("请输入想要替换的的字符串：");
				memset(s1,0,sizeof(s1));
				memset(s2,0,sizeof(s2));
				memset(next,0,sizeof(next));
				gets(s1);
				getnext(next,s1);
				printf("请输入想要取代的字符串：");
				gets(s2);
				head=repalce(head,s1,s2,next);
				head=change_blank(head);	
				printf("替换成功！\n");
				print(head);
				break;
			}
		case 12://块移动
			{
				print(head);
				head=move(head);
				break;
			}
		case 13://释放整个链表
			{
				free_total(head);
				printf("释放成功\n");
				head=init();
				break;
			}
		case 14:
			{
				system("cls");
				printf("\n\n\n\n");
				drawmain4();
				return 0;
			}
		default:
			{
				printf("输入有误，请重新输入\n");
				break;
			}
		}
		printf("按回车键（Enter）返回菜单\n");
		getchar();
		system("cls");
	}
	return 0;
}
